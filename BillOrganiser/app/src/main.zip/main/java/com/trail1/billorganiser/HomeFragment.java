/*
 * Author    : Eswar Aravind Swamy Adari
 * Functions : To display images uploaded by the user
 */

package com.trail1.billorganiser;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    private FloatingActionButton uploadFAB, cameraFAB, albumFAB;
    private TextView camTV, albumTV;
    private Animation fabOpenAnim, fabCloseAnim;
    private static final int PICK_IMAGE = 100;
    Uri imageUri;
    boolean isOpen = false;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        uploadFAB = view.findViewById(R.id.idUploadFloatBtn);
        cameraFAB = view.findViewById(R.id.idCameraFloatBtn);
        albumFAB = view.findViewById(R.id.idAlbumFloatBtn);
        camTV = view.findViewById(R.id.idCameraTV);
        albumTV = view.findViewById(R.id.idAlbumTV);

        fabOpenAnim = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.fab_open);
        fabCloseAnim = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.fab_close);

        // OnClick to open the floating action button
        uploadFAB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(isOpen){

                    cameraFAB.startAnimation(fabCloseAnim);
                    albumFAB.startAnimation(fabCloseAnim);
                    camTV.setVisibility(View.INVISIBLE);
                    albumTV.setVisibility(View.INVISIBLE);

                    isOpen = false;
                }
                else{
                    cameraFAB.startAnimation(fabOpenAnim);
                    albumFAB.startAnimation(fabOpenAnim);
                    camTV.setVisibility(View.VISIBLE);
                    albumTV.setVisibility(View.VISIBLE);

                    isOpen = true;
                }
            }
        });

        //  Open Camera
        cameraFAB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try{
//                    Log.d("In camera try sdf", String.valueOf(87));
                    openCamera();
                }
                catch (Exception e){
//                    Log.d("In camera catch sdf", String.valueOf(e));
                    e.printStackTrace();
                }
            }
        });

        // Open Gallery
        albumFAB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try{
                    openGallery();
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        return view;
    }

    // Method to access device camera using MediaStore
    private void openCamera(){
        Intent cameraIntent = new Intent();
        cameraIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(cameraIntent);
    }

    // Method to load images from gallery using MediaStore
    private void openGallery(){
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, PICK_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == PICK_IMAGE){

            final ImageView billsIV = getView().findViewById(R.id.idBillImgs);
            final List<Bitmap> imgBitmaps = new ArrayList<>();
            ClipData clipData = data.getClipData();

            if(clipData == null){
                imageUri = data.getData();

                // Retrieve the images to the inputStream and add it to bitmap
                try {
                    InputStream imageStream = getActivity().getContentResolver().openInputStream(imageUri);
                    Bitmap imgBitmap = BitmapFactory.decodeStream(imageStream);
                    imgBitmaps.add(imgBitmap);
                }
                catch (Exception e){
                    e.printStackTrace();
                }

                // Thread to retrieve the images from the bitmap set it to the imageview
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        for(final Bitmap b: imgBitmaps){
                            getActivity().runOnUiThread(new Runnable(){
                               @Override
                               public void run(){
                                   billsIV.setImageBitmap(b);
                               }
                            });
                            try {
                                Thread.sleep(2000);
                            }
                            catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();
            }
        }
    }

}